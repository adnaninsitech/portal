


<section class="unit-boxes">
<div class="single-box"><label>This Month</label><h4>$22570</h4></div>
<div class="single-box"><label>Last Month</label><h4>$435700</h4></div>
</section>


<section class="top-three">
<ul>
<li class="second"><img src="images/performer1.jpg"> <h6>Nasir</h6><div class="standing"><h1>2</h1></div></li>
<li class="first"><img src="images/performer2.jpg"> <h6>Adil</h6><div class="standing"><h1>1</h1></div></li>
<li class="third"><img src="images/performer3.jpg"> <h6>Muzaffar</h6><div class="standing"><h1>3</h1></div></li>

</ul>

</section>
<section class="inner-table white-bg">
<h4 class="the-title">Unit Wise Stats</h4>
<div id="all-units">
<div><h6>Monster Logo Design <strong class="gradient-bg">$44220</strong></h6></div>
<div><h6>Resume In Time <strong class="gradient-bg">$1220</strong></h6></div>
<div><h6>Copy Profs<strong class="gradient-bg">$3328</strong></h6></div>
<div><h6>Research Shark<strong class="gradient-bg">$432</strong></h6></div>
<div><h6>Class Room Assistance<strong class="gradient-bg">$6567</strong></h6></div>
<div><h6>Our Writing Lab<strong class="gradient-bg">$15454</strong></h6></div>
<div><h6>E Custom Papers<strong class="gradient-bg">$65</strong></h6></div>
<div><h6>Grade Marvel<strong class="gradient-bg">$0</strong></h6></div>
</div>
</section>